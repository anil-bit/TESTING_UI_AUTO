# -*- coding: utf-8 -*-
"""
Created on Mon Dec 28 14:38:36 2020

@author: zdtbtk
"""

# -*- coding: utf-8 -*-
"""
Created on Wed Dec 23 08:26:00 2020

@author: zdtbtk
"""

# -*- coding: utf-8 -*-
"""
Created on Mon Dec 14 08:49:43 2020

@author: zdtbtk
"""


                                               
                                               
                                               
                                               
                                               
                                               
                                               
                                               
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 10 15:26:36 2020

@author: anil
"""

import os
import tkinter as tk
from tkinter import filedialog
from tkinter import *
from tkinter import ttk
import time
import os
import time
root= tk.Tk()
from threading import Thread
import glob
import time
import tkinter as tk
import tkinter.ttk as ttk


from tkinter import *
import shutil




canvas1 = tk.Canvas(root, width = 2000, height = 2000, bg = 'gray90', relief = 'raised')
canvas1.pack()


'''
with open('C:/Users/Administrator/Documents/Visual Studio 2015/Projects/WindowsFormsApplication6/WindowsFormsApplication6/bin/Debug/now_camera.txt') as f: 
         for line in f:
             c=line.strip()
             print (c) 
             k = c.split('/')
             print(k)
'''


'''
sbar = tk.Scrollbar(root)
sbar.pack(side=tk.RIGHT, fill='y')
canvas1.create_window(1750, 99, window=sbar) 
'''


#from Tkinter import *

#root = Tk()
scrollbar = tk.Scrollbar(root, width=15, troughcolor="red")
#scrollbar.pack( side = RIGHT, fill = Y )

mylist = tk.Listbox(root, yscrollcommand = scrollbar.set, width=500)
#for line in range(100):
 #  mylist.insert(END, "This is line number " + str(line))

#mylist.pack( side = LEFT, fill = BOTH )
scrollbar.config( command = mylist.yview )
canvas1.create_window(240, 499, window=scrollbar)
canvas1.create_window(1750, 499, window=mylist)
#mainloop()


'''
scrollbar1 = tk.Scrollbar(root, width=500, troughcolor="red")
#scrollbar.pack( side = RIGHT, fill = Y )

mylist1 = tk.Listbox(root, yscrollcommand = scrollbar1.set, width=500)
#for line in range(100):
 #  mylist.insert(END, "This is line number " + str(line))

#mylist.pack( side = LEFT, fill = BOTH )
scrollbar1.config( command = mylist1.yview )
canvas1.create_window(50, 699, window=scrollbar1)
canvas1.create_window(1750, 699, window=mylist1)
'''

style = ttk.Style(root)
# add label in the layout
style.layout('text.Horizontal.TProgressbar', 
             [('Horizontal.Progressbar.trough',
               {'children': [('Horizontal.Progressbar.pbar',
                              {'side': 'left', 'sticky': 'ns'})],
                'sticky': 'nswe'}), 
              ('Horizontal.Progressbar.label', {'sticky': ''})])
# set initial text
style.configure('text.Horizontal.TProgressbar', text='0 %')
# create progressbar
#variable = tk.DoubleVar(root)
#root = Tk()

#root.mainloop()
            
style1 = ttk.Style(root)
# add label in the layout
style1.layout('text1.Horizontal.TProgressbar', 
             [('Horizontal.Progressbar.trough',
               {'children': [('Horizontal.Progressbar.pbar',
                              {'side': 'left', 'sticky': 'ns'})],
                'sticky': 'nswe'}), 
              ('Horizontal.Progressbar.label', {'sticky': ''})])
# set initial text
style1.configure('text1.Horizontal.TProgressbar', text='0 %')



style2 = ttk.Style(root)
# add label in the layout
style2.layout('text2.Horizontal.TProgressbar', 
             [('Horizontal.Progressbar.trough',
               {'children': [('Horizontal.Progressbar.pbar',
                              {'side': 'left', 'sticky': 'ns'})],
                'sticky': 'nswe'}), 
              ('Horizontal.Progressbar.label', {'sticky': ''})])
# set initial text
style2.configure('text2.Horizontal.TProgressbar', text='0 %')


style3 = ttk.Style(root)
# add label in the layout
style3.layout('text3.Horizontal.TProgressbar', 
             [('Horizontal.Progressbar.trough',
               {'children': [('Horizontal.Progressbar.pbar',
                              {'side': 'left', 'sticky': 'ns'})],
                'sticky': 'nswe'}), 
              ('Horizontal.Progressbar.label', {'sticky': ''})])
# set initial text
style3.configure('text3.Horizontal.TProgressbar', text='0 %')












style4 = ttk.Style(root)
style4.layout('text4.Horizontal.TProgressbar', 
             [('Horizontal.Progressbar.trough',
               {'children': [('Horizontal.Progressbar.pbar',
                              {'side': 'left', 'sticky': 'ns'})],
                'sticky': 'nswe'}), 
              ('Horizontal.Progressbar.label', {'sticky': ''})])
# set initial text
style4.configure('text4.Horizontal.TProgressbar', text='0 %')
# create progressbar
#variable = tk.DoubleVar(root)
#root = Tk()

#root.mainloop()
            
style5 = ttk.Style(root)
# add label in the layout
style5.layout('text5.Horizontal.TProgressbar', 
             [('Horizontal.Progressbar.trough',
               {'children': [('Horizontal.Progressbar.pbar',
                              {'side': 'left', 'sticky': 'ns'})],
                'sticky': 'nswe'}), 
              ('Horizontal.Progressbar.label', {'sticky': ''})])
# set initial text
style5.configure('text5.Horizontal.TProgressbar', text='0 %')



style6 = ttk.Style(root)
# add label in the layout
style6.layout('text6.Horizontal.TProgressbar', 
             [('Horizontal.Progressbar.trough',
               {'children': [('Horizontal.Progressbar.pbar',
                              {'side': 'left', 'sticky': 'ns'})],
                'sticky': 'nswe'}), 
              ('Horizontal.Progressbar.label', {'sticky': ''})])
# set initial text
style6.configure('text6.Horizontal.TProgressbar', text='0 %')


style7 = ttk.Style(root)
# add label in the layout
style7.layout('text7.Horizontal.TProgressbar', 
             [('Horizontal.Progressbar.trough',
               {'children': [('Horizontal.Progressbar.pbar',
                              {'side': 'left', 'sticky': 'ns'})],
                'sticky': 'nswe'}), 
              ('Horizontal.Progressbar.label', {'sticky': ''})])
# set initial text
style7.configure('text7.Horizontal.TProgressbar', text='0 %')




def go_babe_go():
    
     Thread(target = main_c).start()




def main_c():
                    
                    import time    
                    from threading import Thread    
                    
                    #import os 
                #while True:   
                    dirName = 'C:/Users/Administrator/Pictures/New folder'
                    sirName = 'C:/Users/Administrator/Desktop'
                    while True:        
                        listOfFile = os.listdir(dirName) 
                        
                        no_of_file = len(listOfFile)
                        for r in range(0,no_of_file):
                                #print (listOfFile[r])
                                
                                aaaaaa=dirName +"/"+listOfFile[r]
                                crop_path_a1 = aaaaaa+"/"+listOfFile[r]+"_A_1"
                                crop_path_a2 = aaaaaa+"//"+listOfFile[r]+"_A_2//"
                                crop_path_b1 = aaaaaa+"//"+listOfFile[r]+"_B_1//"
                                crop_path_b2 = aaaaaa+"//"+listOfFile[r]+"_B_2//"
                                bbbbbb = aaaaaa+"/"+'completed.txt'
                                if (os.path.exists(crop_path_a1)) and (os.path.exists(crop_path_a2)) and (os.path.exists(crop_path_b1)) and (os.path.exists(crop_path_b2)):
                                     print("exsists"+crop_path_a1)
                                     input_running.delete(0,"end")
                                     input_running.insert(END,"none")

                                #exists = os.path.isfile(ccc + "/"+kkk[-1] + "_B_1"+"/"+'guru99.txt')
                                    #exists = os.path.isfile(bbbbbb)
                                    #if os.path.exists("crop_path_a1"):
                                     if not os.path.exists(bbbbbb):       
                             #print(aaaaaa) 
                                    
                            
                             
                                            
                             
                            
                             
                                            c_txt = aaaaaa+"/"+"txt"             
                                            if not os.path.exists(c_txt):
                                               os.mkdir(c_txt)
                             
                                            input_running.delete(0,"end")
                                            input_running.insert(END, aaaaaa)
                                            input_entry_1.delete(0,"end")
                                            input_entry_2.delete(0,"end")
                                            input_entry_3.delete(0,"end")
                                            input_entry_4.delete(0,"end")
                                            crop_path_a1 = aaaaaa+"/"+listOfFile[r]+"_A_1/" 
                                            
                                            old_t = sirName+'/'+'test.txt'
                                            if os.path.exists(old_t):
                                               os.remove(old_t)
                                            
                                            
                                            
                                            with open(sirName+'/'+'test.txt', 'w') as a:
                                             a.write(aaaaaa)
                                            cpa1cd = crop_path_a1+"/"+"CROP_DEFECT"
                                            
                                            if os.path.exists(cpa1cd):
                                               shutil.rmtree(cpa1cd)
                                            cpa1cd1 = crop_path_a1+"/"+"CROP_DEFECT_ori"
                                            if os.path.exists(cpa1cd1):
                                               shutil.rmtree(cpa1cd1)
                                               
                                            if not os.path.exists(cpa1cd):
                                               os.mkdir(cpa1cd)    
                                             
                                            if not os.path.exists(cpa1cd1):
                                               os.mkdir(cpa1cd1)   
                                               
                                               
                                               
                                            crop_path_a2 = aaaaaa+"//"+listOfFile[r]+"_A_2//" 
                                            cpa2cd = crop_path_a2+"/"+"CROP_DEFECT"
                                            if os.path.exists(cpa2cd):
                                               shutil.rmtree(cpa2cd)
                                            cpa2cd2 = crop_path_a2+"/"+"CROP_DEFECT_ori"
                                            if os.path.exists(cpa2cd2):
                                               shutil.rmtree(cpa2cd2) 
                                               
                                               
                                            if not os.path.exists(cpa2cd):
                                               os.mkdir(cpa2cd)    
                                             
                                            if not os.path.exists(cpa2cd2):
                                               os.mkdir(cpa2cd2)   
                                               
                                            
                                            crop_path_b1 = aaaaaa+"//"+listOfFile[r]+"_B_1//" 
                                            cpb1cd = crop_path_b1+"/"+"CROP_DEFECT"
                                            if os.path.exists(cpb1cd):
                                               shutil.rmtree(cpb1cd)
                                            cpb1cd1 = crop_path_b1+"/"+"CROP_DEFECT_ori"
                                            if os.path.exists(cpb1cd1):
                                               shutil.rmtree(cpb1cd1)  
                                               
                                            if not os.path.exists(cpb1cd):
                                               os.mkdir(cpb1cd)    
                                             
                                            if not os.path.exists(cpb1cd1):
                                               os.mkdir(cpb1cd1)  
                                               
                                            
                                               
                                            crop_path_b2 = aaaaaa+"//"+listOfFile[r]+"_B_2//" 
                                            cpb2cd = crop_path_b2+"/"+"CROP_DEFECT"
                                            if os.path.exists(cpb2cd):
                                               shutil.rmtree(cpb2cd)
                                            cpb2cd1 = crop_path_b2+"/"+"CROP_DEFECT_ori"
                                            if os.path.exists(cpb2cd1):
                                               shutil.rmtree(cpb2cd1)    
                                            
                                            
                                            if not os.path.exists(cpb2cd):
                                               os.mkdir(cpb2cd)    
                                             
                                            if not os.path.exists(cpb2cd1):
                                               os.mkdir(cpb2cd1) 
                                            
                                            few_folder_c1 = crop_path_a1+"/"+"few"
                                            if not os.path.exists(few_folder_c1):
                                               os.mkdir(few_folder_c1)
                                            
                                            few_folder_c2 = crop_path_a2+"/"+"few"
                                            if not os.path.exists(few_folder_c2):
                                               os.mkdir(few_folder_c2)
                                            
                                            
                                            few_folder_c3 = crop_path_b1+"/"+"few"
                                            if not os.path.exists(few_folder_c3):
                                               os.mkdir(few_folder_c3)
                                               
                                            few_folder_c4 = crop_path_b2+"/"+"few"
                                            if not os.path.exists(few_folder_c4):
                                               os.mkdir(few_folder_c4)  
                                            print("wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww")
                                            
                                            Thread(target = cropa1).start()
                                            #cam1_crop()
                                            Thread(target = cam1_crop).start()
                                            
                                            Thread(target = cropa2).start()
                                            Thread(target = cam2_crop).start()
                                            
                                            Thread(target = cropb1).start()
                                            Thread(target = cam3_crop).start()
                                            Thread(target = cropb2).start()
                                            Thread(target = cam4_crop).start()
                                            
                                            all_crop()
                                            
                                            '''
                                            f = open("C:/Users/Administrator/Desktop/all.txt", "a+")
                                            f.write("\n"+aaaaaa)
                                            f.flush() 
                                            f.seek(0)
                                            content = f.read()
                                            
                                            print (content)
                                            
                                            with open("C:/Users/Administrator/Desktop/all.txt","r") as fin:
                                                 data = fin.read().splitlines(True)
                                            mylist.insert(END, data)
                                            
                                            f.close()
                                            '''
                                            mylist.insert(END, aaaaaa)
                                            root.update()
                                #else:
                                    #print("not in format")
                                
                                
                                else:
                                         print("does not exsist"+ crop_path_a1)
                                         
                                         #mylist1.insert(END, content)
                                         root.update()
                                         time.sleep(20)      
                                
                        
                        
                    
                   #cropa2()
                  # cropb1()
                  # cropb2()
                 
            
            




def anil():
                            input_entry_5.delete(0,"end")
                            input_entry_NG_A1.delete(0,"end")
                            input_entry_OK_A1.delete(0,"end")   
                            Thread(target = myCmd).start()
                            # Thread(target = myCmd).join()
                            Thread(target = cam1).start()  
                            # Thread(target = cam1).join()
                            
                            
                            
                            
def Bnil():
                            input_entry_6.delete(0,"end")
                            input_entry_NG_A2.delete(0,"end")
                            input_entry_OK_A2.delete(0,"end")    
                            Thread(target = myamd).start()
                            Thread(target = cam2).start()
                            
                            
'''                            
def Bnil(): 
    with open('C:/Users/Administrator/Documents/Visual Studio 2015/Projects/WindowsFormsApplication6/WindowsFormsApplication6/bin/Debug/now_camera.txt') as aa: 
         for line in aa:
             ss=line.strip()
             print (ss) 
             rr = ss.split('/')
             print(rr)
             
    uu = ss + "/"+rr[-1] + "_A_2"
    jhh = uu+"/"+"AI_output"
    if os.path.exists(jhh):
       shutil.rmtree(jhh)    
    fuuu = uu+"/"+"guru99.txt"
    if os.path.exists(fuuu):
       os.remove(fuuu)
    Thread(target = myamd).start()
    Thread(target = cam2).start() 
'''    
    
    
    
    
def Cnil(): 
    
    input_entry_7.delete(0,"end")         
    input_entry_NG_B1.delete(0,"end")
    input_entry_OK_B1.delete(0,"end")
    Thread(target = myxmd).start()
    Thread(target = cam3).start() 
    
    
    
    
    
    
def Dnil():
    input_entry_8.delete(0,"end")
    input_entry_NG_B2.delete(0,"end")
    input_entry_OK_B2.delete(0,"end")
    Thread(target = myomd).start()
    Thread(target = cam4).start()

'''
def finala1():
    main_c() 
    time.sleep(20)
    anil()
'''
     
     
 
    
my_progress = ttk.Progressbar(root, orient=HORIZONTAL,
                length=300, style='text.Horizontal.TProgressbar', mode='determinate')
my_progress.pack(pady=20)
canvas1.create_window(250, 100, window=my_progress)



qy_progress = ttk.Progressbar(root, orient=HORIZONTAL,
                length=300, style='text1.Horizontal.TProgressbar', mode='determinate')
qy_progress.pack(pady=20)
canvas1.create_window(250, 150, window=qy_progress)

wy_progress = ttk.Progressbar(root, orient=HORIZONTAL,
                length=300, style='text2.Horizontal.TProgressbar', mode='determinate')
wy_progress.pack(pady=20)
canvas1.create_window(250, 200, window=wy_progress)


ry_progress = ttk.Progressbar(root, orient=HORIZONTAL,
                length=300, style='text3.Horizontal.TProgressbar', mode='determinate')
ry_progress.pack(pady=20)
canvas1.create_window(250, 250, window=ry_progress)

mmy_progress = ttk.Progressbar(root, orient=HORIZONTAL,
                length=300, style='text4.Horizontal.TProgressbar', mode='determinate')
mmy_progress.pack(pady=20)
canvas1.create_window(1300, 100, window=mmy_progress)

qqy_progress = ttk.Progressbar(root, orient=HORIZONTAL,
                length=300, style='text5.Horizontal.TProgressbar', mode='determinate')
qqy_progress.pack(pady=20)
canvas1.create_window(1300, 150, window=qqy_progress)

wwy_progress = ttk.Progressbar(root, orient=HORIZONTAL,
                length=300, style='text6.Horizontal.TProgressbar', mode='determinate')
wwy_progress.pack(pady=20)
canvas1.create_window(1300, 200, window=wwy_progress)

rry_progress = ttk.Progressbar(root, orient=HORIZONTAL,
                length=300, style='text7.Horizontal.TProgressbar', mode='determinate')
rry_progress.pack(pady=20)
canvas1.create_window(1300, 250, window=rry_progress)

my_progress['value'] = 0

my_label = Label(root, text="")
my_label.pack(pady=20)










 
    

button3 = tk.Button(text='testing', command=go_babe_go, bg='red', fg='white', font=('helvetica', 12, 'bold'))



canvas1.create_window(900, 25, window=button3)

cam_a1_label = Label(root, 
					text = "testing A1", bg = "yellow").place(x = 10, 
											y = 89)

cam_a2_label = Label(root, 
					text = "testing A2", bg = "yellow").place(x = 10, 
											y = 139)     
                                               
                                               
cam_b1_label = Label(root, 
					text = "testing B1", bg = "yellow").place(x = 10, 
											y = 189)                                                

cam_b2_label = Label(root, 
					text = "testing B2", bg = "yellow").place(x = 10, 
											y = 239) 

crop_a1_label = Label(root, 
					text = "croping A1", bg = "yellow").place(x = 1050, 
											y = 89)                                               


crop_a2_label = Label(root, 
					text = "croping A2", bg = "yellow").place(x = 1050, 
											y = 139)  


crop_b1_label = Label(root, 
					text = "croping B1", bg = "yellow").place(x = 1050, 
											y = 189) 

crop_b2_label = Label(root, 
					text = "croping B2", bg = "yellow").place(x = 1050, 
											y = 239) 

                                               
time_crop_B2 = Label(root, 
					text = " CROPING Time B2", bg = "ORANGE").place(x = 1500, 
											y = 239)                                                
                                               
                                               
time_crop_B1 = Label(root, 
					text = " CROPING Time B1", bg = "ORANGE").place(x = 1500, 
											y = 189)                                                 
                                               
                                               
time_crop_A2 = Label(root, 
					text = " CROPING Time A2", bg = "ORANGE").place(x = 1500, 
											y = 139)                                                
                                               

                                                     
time_crop_A1 = Label(root, 
					text = " CROPING Time A1", bg = "ORANGE").place(x = 1500, 
											y = 89)                                                      
                                                     
                                                     







time_TEST_B2 = Label(root, 
					text = " TESTING Time B2", bg = "ORANGE").place(x = 630, 
											y = 239)                                                
                                               
                                               
time_TEST_B1 = Label(root, 
					text = " TESTING Time B1", bg = "ORANGE").place(x = 630, 
											y = 189)                                                 
                                               
                                               
time_TEST_A2 = Label(root, 
					text = " TESTING Time A2", bg = "ORANGE").place(x = 630, 
											y = 139)                                                
                                               

                                                     
time_TEST_A1 = Label(root, 
					text = " TESTING Time A1", bg = "ORANGE").place(x = 630, 
											y = 89) 



ng_TEST_A1 = Label(root, 
					text = "   NG   ", bg = "PINK").place(x = 445, 
											y = 60) 


OK_TEST_A1 = Label(root, 
					text = "   OK   ", bg = "PINK").place(x = 530, 
											y = 60) 



running_label = Label(root, 
					text = " runing....", bg = "orange").place(x = 170, 
											y = 340) 
								  



completed_label = Label(root, 
					text = " completed....", bg = "orange").place(x = 150, 
											y = 485) 








                                                     
                                                     
#Output = Text(root, height = 5,  
#              width = 5,  
 #             bg = "light cyan") 
 
input_entry_1 = tk.Entry(text="", width=40)                
canvas1.create_window(1750, 99, window=input_entry_1)                      
#Output.pack() 
input_entry_2 = tk.Entry(text="", width=40)                
canvas1.create_window(1750, 149, window=input_entry_2) 

input_entry_3 = tk.Entry(text="", width=40)                
canvas1.create_window(1750, 199, window=input_entry_3)


input_entry_4 = tk.Entry(text="", width=40)                
canvas1.create_window(1750, 249, window=input_entry_4)






input_entry_8 = tk.Entry(text="", width=40)                
canvas1.create_window(900, 249, window=input_entry_8)

input_entry_7 = tk.Entry(text="", width=40)                
canvas1.create_window(900, 199, window=input_entry_7)

input_entry_6 = tk.Entry(text="", width=40)                
canvas1.create_window(900, 149, window=input_entry_6)

input_entry_5 = tk.Entry(text="", width=40)                
canvas1.create_window(900, 99, window=input_entry_5)




input_entry_NG_A1 = tk.Entry(text="", width=10)                
canvas1.create_window(460, 100, window=input_entry_NG_A1)

input_entry_OK_A1 = tk.Entry(text="", width=10)                
canvas1.create_window(550, 100, window=input_entry_OK_A1)

input_entry_NG_A2 = tk.Entry(text="", width=10)                
canvas1.create_window(460, 149, window=input_entry_NG_A2)

input_entry_OK_A2 = tk.Entry(text="", width=10)                
canvas1.create_window(550, 149, window=input_entry_OK_A2)


input_entry_NG_B1 = tk.Entry(text="", width=10)                
canvas1.create_window(460, 200, window=input_entry_NG_B1)

input_entry_OK_B1 = tk.Entry(text="", width=10)                
canvas1.create_window(550, 200, window=input_entry_OK_B1)

input_entry_NG_B2 = tk.Entry(text="", width=10)                
canvas1.create_window(460, 250, window=input_entry_NG_B2)

input_entry_OK_B2 = tk.Entry(text="", width=10)                
canvas1.create_window(550, 250, window=input_entry_OK_B2)

input_running = tk.Entry(text="", width=160)                
canvas1.create_window(730, 350, window=input_running)


















from threading import Thread
    
    

def cam1():
    while True:
        #try:
          #time.sleep(1)
          with open('C:/Users/Administrator/Desktop/test.txt') as f: 
             for line in f:
                 c=line.strip()
                 #print (c) 
                 k = c.split('/')
                 #print(k)
          u = c + "/"+k[-1] + "_A_1"       
          exists = os.path.isfile(u+"/"+'guru99.txt')
            
          if exists:
             
             j = u + "/CROP_DEFECT_ori"
             ii=len(os.listdir(j))
             cc=ii-3 
             myPath = u + "/AI_output/total"
             y = len(glob.glob1(myPath,"*.jpeg"))
            # print(myPath)
             nyPath = u + "/AI_output/ng/"
             mm = len(glob.glob1(nyPath,"*.jpeg"))
             #time.sleep(1)
            # print(y)
             yy = round((y*100)/ii)
            # print(yy)
             
            # bb =a*2
            # my_progress['value'] < ii
             my_progress['value'] = yy
             my_progress.step()  # increment progressbar 
             style.configure('text.Horizontal.TProgressbar', 
                    text='{:g} %'.format(yy))  # update label
             
        # Keep updating the master object to redraw the progress bar
             root.update()
             
             if yy == 100:
                 
                time.sleep(5) 
                NG_S = u + "/AI_output/ng"
                SIZE_NG =len(os.listdir(NG_S))
                OK_S = u + "/AI_output/ok"
                SIZE_ok =len(os.listdir(OK_S))
                input_entry_NG_A1.insert(END, SIZE_NG)
                input_entry_OK_A1.insert(END, SIZE_ok)
                f= open(c+"/txt/a1.txt","w+")
                f.close()
                mm=open(c+"/"+"completed.txt", "w+")
                mm.close()
                import re
                #import os
                arry=os.listdir(u + "/AI_output/txt/")
                #o_of_filess= len(os.listdir("C:/Users/Administrator/Pictures/New folder/750P02F-ZOSP2-N_830/750P02F-ZOSP2-N_830_A_2/New folder/"))
                
                for file in arry:
                   print (file)
                   sile = file[:-4]
                   Y=re.findall(r'_([^\s_]+)', sile)
                  # print("anil")
                  # o=data[int(Y[1])]
                   #print(o)
                   print(Y)
                   with open(u+"/new/NG"+Y[0]+"_"+Y[0]+".ngt","r") as fin:
                       data = fin.read().splitlines(True)
                   with open(u+"/few/NG"+Y[0]+"_"+Y[0]+".ngt","a+") as fout:    
                       fout.writelines(data[(int(Y[1]))-1])
                root.update()
                break 
        #except:
           # pass





def cam2():         
    while True:
        #try:
          with open('C:/Users/Administrator/Desktop/test.txt') as ff: 
             for line in ff:
                 cc=line.strip()
                # print (cc) 
                 kk = cc.split('/')
                # print(kk)
          #time.sleep(1)
          uu = cc + "/"+kk[-1] + "_A_2"
          exists = os.path.isfile(cc + "/"+kk[-1] + "_A_2"+"/"+'guru99.txt')
            
          if exists:
             
             jj = uu + "/CROP_DEFECT_ori"
             ii_i=len(os.listdir(jj))
             cc_c=ii_i-3 
             myPathh = uu + "/AI_output/total"
             yy = len(glob.glob1(myPathh,"*.jpeg"))
             #print(myPathh)
             nyPathh = uu + "/AI_output/ng"
             mm_m = len(glob.glob1(nyPathh,"*.jpeg"))
             #time.sleep(1)
            # print(yy)
             hh = round((yy*100)/ii_i)
             #print(hh)
             
            # bb =a*2
            # my_progress['value'] < ii
             qy_progress['value'] = hh
             qy_progress.step()  # increment progressbar 
             style1.configure('text1.Horizontal.TProgressbar', 
                    text='{:g} %'.format(hh))  # update label
             
        # Keep updating the master object to redraw the progress bar
             root.update()
             
             if hh == 100:
                time.sleep(5) 
                NG_S_2 = uu + "/AI_output/ng"
                SIZE_NG_2 =len(os.listdir(NG_S_2))
                OK_S_2 = uu + "/AI_output/ok"
                SIZE_ok_2 =len(os.listdir(OK_S_2))
                input_entry_NG_A2.insert(END, SIZE_NG_2)
                input_entry_OK_A2.insert(END, SIZE_ok_2)
                f= open(cc + "/txt/a2.txt","w+")
                f.close()
                mm=open(cc+"/"+"completed.txt", "w+")
                mm.close()
                import re
                #import os
                arry=os.listdir(uu + "/AI_output/txt/")
                #o_of_filess= len(os.listdir("C:/Users/Administrator/Pictures/New folder/750P02F-ZOSP2-N_830/750P02F-ZOSP2-N_830_A_2/New folder/"))
                
                for file in arry:
                   print (file)
                   sile = file[:-4]
                   Y=re.findall(r'_([^\s_]+)', sile)
                  # print("anil")
                  # o=data[int(Y[1])]
                   #print(o)
                   print(Y)
                   with open(uu+"/new/NG"+Y[0]+"_"+Y[0]+".ngt","r") as fin:
                       data = fin.read().splitlines(True)
                   with open(uu+"/few/NG"+Y[0]+"_"+Y[0]+".ngt","a+") as fout:    
                       fout.writelines(data[(int(Y[1]))-1])
                root.update()
                break      
       # except:
        #    pass  
         
def cam3():         
    while True:
        try:
          with open('C:/Users/Administrator/Desktop/test.txt') as fff: 
                 for line in fff:
                     ccc=line.strip()
                     #print (ccc) 
                     kkk = ccc.split('/')
                     #print(kkk)
          #time.sleep(1)
          exists = os.path.isfile(ccc + "/"+kkk[-1] + "_B_1"+"/"+'guru99.txt')
            
          if exists:
             uuu = ccc + "/"+kkk[-1] + "_B_1"
             jjj = uuu + "/CROP_DEFECT_ori"
             ii_ii=len(os.listdir(jjj))
             cc_cc=ii_ii-3 
             myPathhh = uuu + "/AI_output/total"
             yyy = len(glob.glob1(myPathhh,"*.jpeg"))
             #print(myPathhh)
             nyPathhh = uuu + "/AI_output/ng"
             mm_mm = len(glob.glob1(nyPathhh,"*.jpeg"))
             #time.sleep(1)
            # print(yyy)
             qw = round((yyy*100)/ii_ii)
            # print(qw)
             
            # bb =a*2
            # my_progress['value'] < ii
             wy_progress['value'] = qw
             wy_progress.step()  # increment progressbar 
             style2.configure('text2.Horizontal.TProgressbar', 
                    text='{:g} %'.format(qw))  # update label
             
        # Keep updating the master object to redraw the progress bar
             root.update()
             
             if qw == 100:
                time.sleep(5) 
                NG_S_3 = uuu + "/AI_output/ng"
                SIZE_NG_3 =len(os.listdir(NG_S_3))
                OK_S_3 = uuu + "/AI_output/OK"
                SIZE_ok_3 =len(os.listdir(OK_S_3))
                input_entry_NG_B1.insert(END, SIZE_NG_3)
                input_entry_OK_B1.insert(END, SIZE_ok_3)  
                f= open(ccc + "/txt/b1.txt","w+")
                f.close() 
                mm=open(ccc+"/"+"completed.txt", "w+")
                mm.close()
                import re
                #import os
                arry=os.listdir(uuu + "/AI_output/txt/")
                #o_of_filess= len(os.listdir("C:/Users/Administrator/Pictures/New folder/750P02F-ZOSP2-N_830/750P02F-ZOSP2-N_830_A_2/New folder/"))
                
                for file in arry:
                   print (file)
                   sile = file[:-4]
                   Y=re.findall(r'_([^\s_]+)', sile)
                  # print("anil")
                  # o=data[int(Y[1])]
                   #print(o)
                   print(Y)
                   with open(uuu+"/new/NG"+Y[0]+"_"+Y[0]+".ngt","r") as fin:
                       data = fin.read().splitlines(True)
                   with open(uuu+"/few/NG"+Y[0]+"_"+Y[0]+".ngt","a+") as fout:    
                       fout.writelines(data[(int(Y[1]))-1])
                root.update()
                break  
        except:
            pass  
         
         
def cam4():         
    while True:
        try:
          with open('C:/Users/Administrator/Desktop/test.txt') as ffff: 
                 for line in ffff:
                     cccc=line.strip()
                    # print (cccc) 
                     kkkk = cccc.split('/')
                    # print(kkkk)
          #time.sleep(1)
          exists = os.path.isfile(cccc + "/"+kkkk[-1] + "_B_2"+"/"+'guru99.txt')
            
          if exists:
             uuuu = cccc + "/"+kkkk[-1] + "_B_2"
             jjjj = uuuu + "/CROP_DEFECT_ori"
             ii_iii=len(os.listdir(jjjj))
             cc_ccc=ii_iii-3 
             myPathhhh = uuuu + "/AI_output/total"
             yyyy = len(glob.glob1(myPathhhh,"*.jpeg"))
            # print(myPathhhh)
             nyPathhhh = uuuu + "/AI_output/ng"
             mm_mmm = len(glob.glob1(nyPathhhh,"*.jpeg"))
             #time.sleep(1)
            # print(yyyy)
             oo = round((yyyy*100)/ii_iii)
             #print(oo)
             
            # bb =a*2
            # my_progress['value'] < ii
             ry_progress['value'] = oo
             ry_progress.step()  # increment progressbar 
             style3.configure('text3.Horizontal.TProgressbar', 
                    text='{:g} %'.format(oo))  # update label
             
        # Keep updating the master object to redraw the progress bar
             root.update()
             
             if oo == 100:
                time.sleep(5) 
                NG_S_4 = uuuu + "/AI_output/ng"
                SIZE_NG_4 =len(os.listdir(NG_S_4))
                OK_S_4 = uuuu + "/AI_output/ok"
                SIZE_ok_4 =len(os.listdir(OK_S_4))
                input_entry_NG_B2.insert(END, SIZE_NG_4)
                input_entry_OK_B2.insert(END, SIZE_ok_4) 
                f= open(cccc + "/txt/b2.txt","w+")
                f.close()
                mm=open(cccc+"/"+"completed.txt", "w+")
                mm.close()
                import re
                #import os
                arry=os.listdir(uuuu + "/AI_output/txt/")
                #o_of_filess= len(os.listdir("C:/Users/Administrator/Pictures/New folder/750P02F-ZOSP2-N_830/750P02F-ZOSP2-N_830_A_2/New folder/"))
                
                for file in arry:
                   print (file)
                   sile = file[:-4]
                   Y=re.findall(r'_([^\s_]+)', sile)
                  # print("anil")
                  # o=data[int(Y[1])]
                   #print(o)
                   print(Y)
                   with open(uuuu+"/new/NG"+Y[0]+"_"+Y[0]+".ngt","r") as fin:
                       data = fin.read().splitlines(True)
                   with open(uuuu+"/few/NG"+Y[0]+"_"+Y[0]+".ngt","a+") as fout:    
                       fout.writelines(data[(int(Y[1]))-1])
                root.update()
                break            
        except:
            pass





















def myCmd ():
 #   model_pathh=open("C:/Users/venka/OneDrive/Desktop/deep_learning.txt", "r")
#    model_path=model_pathh.read()

    #button1["state"] = "disabled"
   
    import time
    start_time = time.time()
            
    os.system('cmd/k "CALL conda.bat activate && activate strong && cd C:/Users/Administrator/Desktop/yolov5 && python detect.py"')
    cam_t_a1_TEST=  (time.time() - start_time)                      
   # print("--- %s seconds ---" % cam_t_a1_TEST) 
    input_entry_5.insert(END, cam_t_a1_TEST)    
    exit()
    
    
    
    
def myamd ():
 #   model_pathh=open("C:/Users/venka/OneDrive/Desktop/deep_learning.txt", "r")
#    model_path=model_pathh.read()
   
   # button3["state"] = "disabled"  
    import time
    start_time = time.time()       
    os.system('cmd/k "CALL conda.bat activate && activate strong && cd C:/Users/Administrator/Desktop/yolov5 && python detect_cam_a2.py"')  
    cam_t_a2_TEST=  (time.time() - start_time)                      
    #print("--- %s seconds ---" % cam_t_a2_TEST) 
    input_entry_6.insert(END, cam_t_a2_TEST)    
    exit()  
    
    
    
    
def myxmd ():
 #   model_pathh=open("C:/Users/venka/OneDrive/Desktop/deep_learning.txt", "r")
#    model_path=model_pathh.read()
   # button5["state"] = "disabled"
    import time
    start_time = time.time() 
    os.system('cmd/k "CALL conda.bat activate && activate strong && cd C:/Users/Administrator/Desktop/yolov5 && python detect_cam_b1.py"')
    cam_t_b1_TEST=  (time.time() - start_time)                      
   # print("--- %s seconds ---" % cam_t_b1_TEST) 
    input_entry_7.insert(END, cam_t_b1_TEST)
    exit()    

def myomd ():
 #   model_pathh=open("C:/Users/venka/OneDrive/Desktop/deep_learning.txt", "r")
#    model_path=model_pathh.read()
     # button7["state"] = "disabled"
     import time
     start_time = time.time()
     os.system('cmd/k "CALL conda.bat activate && activate strong && cd C:/Users/Administrator/Desktop/yolov5 && python detect_cam_b2.py"')   
     cam_t_b2_TEST=  (time.time() - start_time)                      
     #print("--- %s seconds ---" % cam_t_b2_TEST) 
     input_entry_8.insert(END, cam_t_b2_TEST)
     exit() 


























    
    
    
    
def cropa1():
    
            import time
            start_time = time.time()
        
            from PIL import Image  
            import  numpy
            import cv2
            import os
            import os
            Image.MAX_IMAGE_PIXELS = 1000000000            
            with open('C:/Users/Administrator/Desktop/test.txt') as aa: 
                     for line in aa:
                         ss=line.strip()
                         #print (ss) 
                         rr = ss.split('/')
#                         print(rr)
    
            uu = ss + "/"+rr[-1] + "_A_1"
            No_of_filess = len(os.listdir(uu+'/'+'ngpointdata'))
           # print(No_of_filess) 
            n_f = uu+"//new//"            
            if not os.path.exists(n_f):
                os.mkdir(n_f)
            savePath = uu+"//checkimg//"
            navePath = uu+"//CROP_DEFECT//" 
            newpath = uu+"//CROP_DEFECT_ori//"
            if not os.path.exists(navePath):
                os.mkdir(navePath)           
                        
            arr=os.listdir(uu+'/'+'ngpointdata')

            

            
            for c in range(1,No_of_filess):
                with open(uu+"/ngpointdata//"+arr[c],"r") as fin:
                    data = fin.read().splitlines(True)
                with open(uu+"/new//"+arr[c],"w") as fout:    
                    fout.writelines(data[2:])
            f= open(uu+"/"+"anil.txt","w+")
            f.close()        
            for c in range(1,No_of_filess):            
                file = open(uu+"/new//"+arr[c],"r")
                image_no = 0
                            
                img =numpy.asarray(Image.open(savePath+"R_"+arr[c][:-4]+'.jpg'))
                img1 =numpy.asarray(Image.open(savePath+'G_'+arr[c][:-4]+'.jpg'))
                img2 =numpy.asarray(Image.open(savePath+'B_'+arr[c][:-4]+'.jpg'))   
                
                            
                for line in file:
                    try:
                                
                                    
                                    
                                    fields = line.split(",")
                                    crop_img = img[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                                    crop_img1 = img1[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                                    crop_img2 = img2[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                                   # print(fields[0])
                                    
                                    image_no += 1
                                    
                                    #img_rgb = cv2.merge([Bb,Gb,Rb])
                                    img_rgb = cv2.merge([crop_img2,crop_img1,crop_img])
                                    
                                    
                                    
                                    cv2.imwrite(navePath+arr[c][:-4]+"_"+fields[0]+".jpeg", img_rgb)
                                    
                                    #cv2.imwrite(davePath+"pic_"+str(c)+".jpg", crop_img)
                                    image = Image.open(navePath+arr[c][:-4]+"_"+fields[0]+".jpeg")
                                    new_image = image.resize((400, 400))
                                    new_image.save(newpath+arr[c][:-4]+"_"+fields[0]+".jpeg")
                    except:
                     pass                  
           
            cam_t_a1_crop=  (time.time() - start_time)                      
            #print("--- %s seconds ---" % cam_t_a1_crop) 
            input_entry_1.insert(END, cam_t_a1_crop)
            
    
    
    
    
def cropa2():
    
            import time
            start_time = time.time()
        
            from PIL import Image  
            import  numpy
            import cv2
            import os
            import os
            Image.MAX_IMAGE_PIXELS = 1000000000            
            with open('C:/Users/Administrator/Desktop/test.txt') as aa: 
                     for line in aa:
                         ss=line.strip()
                         #print (ss) 
                         rr = ss.split('/')
#                         print(rr)
    
            uu = ss + "/"+rr[-1] + "_A_2"
            No_of_filess = len(os.listdir(uu+'/'+'ngpointdata'))
           # print(No_of_filess) 
            n_f = uu+"//new//"            
            if not os.path.exists(n_f):
                os.mkdir(n_f)
            savePath = uu+"//checkimg//"
            navePath = uu+"//CROP_DEFECT//" 
            newpath = uu+"//CROP_DEFECT_ori//"
            if not os.path.exists(navePath):
                os.mkdir(navePath)           
                        
            arr=os.listdir(uu+'/'+'ngpointdata')

            

            
            for c in range(1,No_of_filess):
                with open(uu+"/ngpointdata//"+arr[c],"r") as fin:
                    data = fin.read().splitlines(True)
                with open(uu+"/new//"+arr[c],"w") as fout:    
                    fout.writelines(data[2:])
            f= open(uu+"/"+"anil.txt","w+")
            f.close()        
            for c in range(1,No_of_filess):            
                file = open(uu+"/new//"+arr[c],"r")
                image_no = 0
                            
                img =numpy.asarray(Image.open(savePath+"R_"+arr[c][:-4]+'.jpg'))
                img1 =numpy.asarray(Image.open(savePath+'G_'+arr[c][:-4]+'.jpg'))
                img2 =numpy.asarray(Image.open(savePath+'B_'+arr[c][:-4]+'.jpg'))   
                
                            
                for line in file:
                    try:
                                
                                    
                                    
                                    fields = line.split(",")
                                    crop_img = img[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                                    crop_img1 = img1[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                                    crop_img2 = img2[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                                   # print(fields[0])
                                    
                                    image_no += 1
                                    
                                    #img_rgb = cv2.merge([Bb,Gb,Rb])
                                    img_rgb = cv2.merge([crop_img2,crop_img1,crop_img])
                                    
                                    
                                    
                                    cv2.imwrite(navePath+arr[c][:-4]+"_"+fields[0]+".jpeg", img_rgb)
                                    
                                    #cv2.imwrite(davePath+"pic_"+str(c)+".jpg", crop_img)
                                    image = Image.open(navePath+arr[c][:-4]+"_"+fields[0]+".jpeg")
                                    new_image = image.resize((400, 400))
                                    new_image.save(newpath+arr[c][:-4]+"_"+fields[0]+".jpeg")
                    except:
                     pass 
            
            cam_t_a2_crop=  (time.time() - start_time)                      
            #print("--- %s seconds ---" % cam_t_a2_crop) 
            input_entry_2.insert(END, cam_t_a2_crop)
                    
            
            
            
            
            
            
'''            
    directory_pathh = aaaaaa+"//"+listOfFile[r]+"_A_2//"
    f= open(directory_pathh+"anil.txt","w+")
    f.close()
    No_of_filess = len(os.listdir(directory_pathh+'ngpointdata'))
    print(No_of_filess) 
    n_f = directory_pathh+"//new//"            
    if not os.path.exists(n_f):
        os.mkdir(n_f)
    savePath = directory_pathh+"//checkimg//"
    navePath = directory_pathh+"//CROP_DEFECT//" 
    newpath = directory_pathh+"//CROP_DEFECT_ori//"
    if not os.path.exists(navePath):
        os.mkdir(navePath)           
                
    arr=os.listdir(directory_pathh+'ngpointdata')            
    for c in range(1,No_of_filess):
        with open(directory_pathh+"ngpointdata//"+arr[c],"r") as fin:
            data = fin.read().splitlines(True)
        with open(directory_pathh+"new//"+arr[c],"w") as fout:    
            fout.writelines(data[2:])
                
        file = open(directory_pathh+"new//"+arr[c],"r")
        image_no = 0
                    
        img =numpy.asarray(Image.open(savePath+"R_"+arr[c][:-4]+'.jpg'))
        img1 =numpy.asarray(Image.open(savePath+'G_'+arr[c][:-4]+'.jpg'))
        img2 =numpy.asarray(Image.open(savePath+'B_'+arr[c][:-4]+'.jpg'))   
        
                    
        for line in file:
            try:
            
                        
                            
                            
                            fields = line.split(",")
                            crop_img = img[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                            crop_img1 = img1[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                            crop_img2 = img2[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                            print(fields[0])
                            
                            image_no += 1
                            
                            #img_rgb = cv2.merge([Bb,Gb,Rb])
                            img_rgb = cv2.merge([crop_img2,crop_img1,crop_img])
                            
                            
                            
                            cv2.imwrite(navePath+arr[c][:-4]+"_"+fields[0]+".jpeg", img_rgb)
                            
                            #cv2.imwrite(davePath+"pic_"+str(c)+".jpg", crop_img)
                            image = Image.open(navePath+arr[c][:-4]+"_"+fields[0]+".jpeg")
                            new_image = image.resize((400, 400))
                            new_image.save(newpath+arr[c][:-4]+"_"+fields[0]+".jpeg")  
                            
            except:
             pass                 
                            
    cam_t_a2_crop=  (time.time() - start_time)                      
    print("--- %s seconds ---" % cam_t_a2_crop) 
    input_entry_2.insert(END, cam_t_a2_crop)                      
                            
'''                              
                            
def cropb1():
    
            import time
            start_time = time.time()
        
            from PIL import Image  
            import  numpy
            import cv2
            import os
            import os
            Image.MAX_IMAGE_PIXELS = 1000000000            
            with open('C:/Users/Administrator/Desktop/test.txt') as aa: 
                     for line in aa:
                         ss=line.strip()
                         #print (ss) 
                         rr = ss.split('/')
#                         print(rr)
    
            uu = ss + "/"+rr[-1] + "_B_1"
            No_of_filess = len(os.listdir(uu+'/'+'ngpointdata'))
           # print(No_of_filess) 
            n_f = uu+"//new//"            
            if not os.path.exists(n_f):
                os.mkdir(n_f)
            savePath = uu+"//checkimg//"
            navePath = uu+"//CROP_DEFECT//" 
            newpath = uu+"//CROP_DEFECT_ori//"
            if not os.path.exists(navePath):
                os.mkdir(navePath)           
                        
            arr=os.listdir(uu+'/'+'ngpointdata')

            

            
            for c in range(1,No_of_filess):
                with open(uu+"/ngpointdata//"+arr[c],"r") as fin:
                    data = fin.read().splitlines(True)
                with open(uu+"/new//"+arr[c],"w") as fout:    
                    fout.writelines(data[2:])
            f= open(uu+"/"+"anil.txt","w+")
            f.close()        
            for c in range(1,No_of_filess):            
                file = open(uu+"/new//"+arr[c],"r")
                image_no = 0
                            
                img =numpy.asarray(Image.open(savePath+"R_"+arr[c][:-4]+'.jpg'))
                img1 =numpy.asarray(Image.open(savePath+'G_'+arr[c][:-4]+'.jpg'))
                img2 =numpy.asarray(Image.open(savePath+'B_'+arr[c][:-4]+'.jpg'))   
                
                            
                for line in file:
                    try:
                                
                                    
                                    
                                    fields = line.split(",")
                                    crop_img = img[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                                    crop_img1 = img1[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                                    crop_img2 = img2[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                                   # print(fields[0])
                                    
                                    image_no += 1
                                    
                                    #img_rgb = cv2.merge([Bb,Gb,Rb])
                                    img_rgb = cv2.merge([crop_img2,crop_img1,crop_img])
                                    
                                    
                                    
                                    cv2.imwrite(navePath+arr[c][:-4]+"_"+fields[0]+".jpeg", img_rgb)
                                    
                                    #cv2.imwrite(davePath+"pic_"+str(c)+".jpg", crop_img)
                                    image = Image.open(navePath+arr[c][:-4]+"_"+fields[0]+".jpeg")
                                    new_image = image.resize((400, 400))
                                    new_image.save(newpath+arr[c][:-4]+"_"+fields[0]+".jpeg")
                    except:
                     pass                             
            
            cam_t_b1_crop=  (time.time() - start_time)                      
            #print("--- %s seconds ---" % cam_t_b1_crop) 
            input_entry_3.insert(END, cam_t_b1_crop)
                 
            
            
            
            
            
'''            
def cropb1():
    import time
    start_time = time.time()
    from PIL import Image  
    import  numpy
    import cv2
    import os
    import os
    Image.MAX_IMAGE_PIXELS = 1000000000            
    dirName = 'C:/Users/Administrator/Pictures'            
    listOfFile = os.listdir(dirName)    
    no_of_file = len(listOfFile)
    for r in range(0,no_of_file):
                #print (listOfFile[r])
            aaaaaa=dirName +"/"+listOfFile[r]        
            
            
            
            
            
    directory_pathh = aaaaaa+"//"+listOfFile[r]+"_B_1//"
    f= open(directory_pathh+"anil.txt","w+")
    f.close()
    No_of_filess = len(os.listdir(directory_pathh+'ngpointdata'))
    print(No_of_filess) 
    n_f = directory_pathh+"//new//"            
    if not os.path.exists(n_f):
        os.mkdir(n_f)
    savePath = directory_pathh+"//checkimg//"
    navePath = directory_pathh+"//CROP_DEFECT//" 
    newpath = directory_pathh+"//CROP_DEFECT_ori//"
    if not os.path.exists(navePath):
        os.mkdir(navePath)           
                
    arr=os.listdir(directory_pathh+'ngpointdata')            
    for c in range(1,No_of_filess):
        with open(directory_pathh+"ngpointdata//"+arr[c],"r") as fin:
            data = fin.read().splitlines(True)
        with open(directory_pathh+"new//"+arr[c],"w") as fout:    
            fout.writelines(data[2:])
                
        file = open(directory_pathh+"new//"+arr[c],"r")
        image_no = 0
                    
        img =numpy.asarray(Image.open(savePath+"R_"+arr[c][:-4]+'.jpg'))
        img1 =numpy.asarray(Image.open(savePath+'G_'+arr[c][:-4]+'.jpg'))
        img2 =numpy.asarray(Image.open(savePath+'B_'+arr[c][:-4]+'.jpg'))   
        
                    
        for line in file:
            try:
           
                        
                            
                            
                            fields = line.split(",")
                            crop_img = img[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                            crop_img1 = img1[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                            crop_img2 = img2[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                            print(fields[0])
                            
                            image_no += 1
                            
                            #img_rgb = cv2.merge([Bb,Gb,Rb])
                            img_rgb = cv2.merge([crop_img2,crop_img1,crop_img])
                            
                            
                            
                            cv2.imwrite(navePath+arr[c][:-4]+"_"+fields[0]+".jpeg", img_rgb)
                            
                            #cv2.imwrite(davePath+"pic_"+str(c)+".jpg", crop_img)
                            image = Image.open(navePath+arr[c][:-4]+"_"+fields[0]+".jpeg")
                            new_image = image.resize((400, 400))
                            new_image.save(newpath+arr[c][:-4]+"_"+fields[0]+".jpeg") 
                            
            except:
             pass                
                            
    cam_t_b1_crop=  (time.time() - start_time)                      
    print("--- %s seconds ---" % cam_t_b1_crop) 
    input_entry_3.insert(END, cam_t_b1_crop)                    
'''                            
                                         



def cropb2():
    
            import time
            start_time = time.time()
        
            from PIL import Image  
            import  numpy
            import cv2
            ##import os
            #import os
            Image.MAX_IMAGE_PIXELS = 1000000000            
            with open('C:/Users/Administrator/Desktop/test.txt') as aa: 
                     for line in aa:
                         ss=line.strip()
                         #print (ss) 
                         rr = ss.split('/')
#                         print(rr)        
            
            uu = ss + "/"+rr[-1] + "_B_2"
            No_of_filess = len(os.listdir(uu+'/'+'ngpointdata'))
           # print(No_of_filess) 
            n_f = uu+"//new//"            
            if not os.path.exists(n_f):
                os.mkdir(n_f)
            savePath = uu+"//checkimg//"
            navePath = uu+"//CROP_DEFECT//" 
            newpath = uu+"//CROP_DEFECT_ori//"
            if not os.path.exists(navePath):
                os.mkdir(navePath)           
                        
            arr=os.listdir(uu+'/'+'ngpointdata')
            
            for c in range(1,No_of_filess):
                with open(uu+"/ngpointdata//"+arr[c],"r") as fin:
                    data = fin.read().splitlines(True)
                with open(uu+"/new//"+arr[c],"w") as fout:    
                    fout.writelines(data[2:])
            f= open(uu+"/"+"anil.txt","w+")
            f.close()        
            for c in range(1,No_of_filess):            
                file = open(uu+"/new//"+arr[c],"r")
                image_no = 0
                            
                img =numpy.asarray(Image.open(savePath+"R_"+arr[c][:-4]+'.jpg'))
                img1 =numpy.asarray(Image.open(savePath+'G_'+arr[c][:-4]+'.jpg'))
                img2 =numpy.asarray(Image.open(savePath+'B_'+arr[c][:-4]+'.jpg'))   
                
                            
                for line in file:
                    try:
                                
                                    
                                    
                                    fields = line.split(",")
                                    crop_img = img[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                                    crop_img1 = img1[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                                    crop_img2 = img2[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                                   # print(fields[0])
                                    
                                    image_no += 1
                                    
                                    #img_rgb = cv2.merge([Bb,Gb,Rb])
                                    img_rgb = cv2.merge([crop_img2,crop_img1,crop_img])
                                    
                                    
                                    
                                    cv2.imwrite(navePath+arr[c][:-4]+"_"+fields[0]+".jpeg", img_rgb)
                                    
                                    #cv2.imwrite(davePath+"pic_"+str(c)+".jpg", crop_img)
                                    image = Image.open(navePath+arr[c][:-4]+"_"+fields[0]+".jpeg")
                                    new_image = image.resize((400, 400))
                                    new_image.save(newpath+arr[c][:-4]+"_"+fields[0]+".jpeg")
                    except:
                     pass


            cam_t_b2_crop=  (time.time() - start_time)                      
            #print("--- %s seconds ---" % cam_t_b2_crop) 
            input_entry_4.insert(END, cam_t_b2_crop)    



'''            
   
def cropb2():
    import time
    start_time = time.time()
    from PIL import Image  
    import  numpy
    import cv2
    import os
    import os
    Image.MAX_IMAGE_PIXELS = 1000000000            
    dirName = 'C:/Users/Administrator/Pictures'            
    listOfFile = os.listdir(dirName)    
    no_of_file = len(listOfFile)
    for r in range(0,no_of_file):
                #print (listOfFile[r])
            aaaaaa=dirName +"/"+listOfFile[r]        
            
            
            
            
            
    directory_pathh = aaaaaa+"//"+listOfFile[r]+"_B_2//"
    f= open(directory_pathh+"anil.txt","w+")
    f.close()
    No_of_filess = len(os.listdir(directory_pathh+'ngpointdata'))
    print(No_of_filess) 
    n_f = directory_pathh+"//new//"            
    if not os.path.exists(n_f):
        os.mkdir(n_f)
    savePath = directory_pathh+"//checkimg//"
    navePath = directory_pathh+"//CROP_DEFECT//" 
    newpath = directory_pathh+"//CROP_DEFECT_ori//"
    if not os.path.exists(navePath):
        os.mkdir(navePath)           
                
    arr=os.listdir(directory_pathh+'ngpointdata')            
    for c in range(1,No_of_filess):
        with open(directory_pathh+"ngpointdata//"+arr[c],"r") as fin:
            data = fin.read().splitlines(True)
        with open(directory_pathh+"new//"+arr[c],"w") as fout:    
            fout.writelines(data[2:])
                
        file = open(directory_pathh+"new//"+arr[c],"r")
        image_no = 0
                    
        img =numpy.asarray(Image.open(savePath+"R_"+arr[c][:-4]+'.jpg'))
        img1 =numpy.asarray(Image.open(savePath+'G_'+arr[c][:-4]+'.jpg'))
        img2 =numpy.asarray(Image.open(savePath+'B_'+arr[c][:-4]+'.jpg'))   
        
                    
        for line in file:
            try:
            
                        
                            
                            
                            fields = line.split(",")
                            crop_img = img[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                            crop_img1 = img1[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                            crop_img2 = img2[int(fields[2])-200:int(fields[2])+200, int(fields[1])-200:int(fields[1])+200]
                            print(fields[0])
                            
                            image_no += 1
                            
                            #img_rgb = cv2.merge([Bb,Gb,Rb])
                            img_rgb = cv2.merge([crop_img2,crop_img1,crop_img])
                            
                            
                            
                            cv2.imwrite(navePath+arr[c][:-4]+"_"+fields[0]+".jpeg", img_rgb)
                            
                            #cv2.imwrite(davePath+"pic_"+str(c)+".jpg", crop_img)
                            image = Image.open(navePath+arr[c][:-4]+"_"+fields[0]+".jpeg")
                            new_image = image.resize((400, 400))
                            new_image.save(newpath+arr[c][:-4]+"_"+fields[0]+".jpeg")
                            
                            
            except:
             pass                
                            
                            
    cam_t_b2_crop=  (time.time() - start_time)                      
    print("--- %s seconds ---" % cam_t_b2_crop) 
    input_entry_4.insert(END, cam_t_b2_crop)                        
                
    

'''    
    


          
def cam1_crop():
    while True:
        
           # import os
            bn =[] 
            with open('C:/Users/Administrator/Desktop/test.txt') as aa: 
                 for line in aa:
                     ss=line.strip()
                    # print (ss) 
                     rr = ss.split('/')
                     #print(rr)
                     
            uu = ss + "/"+rr[-1] + "_A_1"
            exists = os.path.isfile(uu+"/"+"anil.txt")
            
            if exists:
                
        
                directory_pathh = uu
                No_of_filess = len(os.listdir(directory_pathh+'/'+'ngpointdata'))
                arr=os.listdir(directory_pathh+"//ngpointdata")
                for c in range(1,No_of_filess):  
                           # with open(directory_pathh+"//old//NG"+str(c)+"_"+str(c)+".ngt","w") as fout: 
                                 #fout.writelines(data[1]) 
                          
                            
                            
                            file = open(directory_pathh+"//new//"+arr[c],"r") 
                            
                            
                            
                            Counter = 0
                              
                            # Reading from file 
                            Content = file.read() 
                            CoList = Content.split("\n") 
                              
                            for i in CoList: 
                                if i: 
                                    Counter += 1
                                      
                            # print("This is the number of lines in the file") 
                            # print(Counter) 
                            bn.append(Counter) 
                total = sum(bn)
                           # print(total, "total")
                #while True:
                      #time.sleep(1)
                          
                          
                        #print(No_of_filess) 
                          
                          
                             
                j = directory_pathh+'/'+"CROP_DEFECT"
                ii=len(os.listdir(j))
                                 
                                
                yy = round((ii*100)/total)
                              #print(yy, "percentage")
                                 
                                # bb =a*2
                                # my_progress['value'] < ii
                mmy_progress['value'] = yy
                mmy_progress.step()  # increment progressbar 
                style4.configure('text4.Horizontal.TProgressbar', 
                                        text='{:g} %'.format(yy))  # update label
                                 
                            # Keep updating the master object to redraw the progress bar
                root.update()
                if yy == 100:
                    Thread(target = anil).start() 
                                    
                    root.update()
                    
                    
                    break
                           
                                                     
                     
                         
                        
                    # else:
                     #   print("not present")
             
def cam2_crop():
    while True:
        
            #import os
            bn2 =[] 
            with open('C:/Users/Administrator/Desktop/test.txt') as aa: 
                 for line in aa:
                     ss=line.strip()
                    # print (ss) 
                     rr = ss.split('/')
                     #print(rr) 
                     
            uu = ss + "/"+rr[-1] + "_A_2"
            exists = os.path.isfile(uu+"/"+"anil.txt")         
                     
            if exists: 
                directory_pathh2 = uu
                No_of_filess2 = len(os.listdir(directory_pathh2+'/ngpointdata'))
                arr=os.listdir(directory_pathh2+"//ngpointdata")
                for cc in range(1,No_of_filess2):  
                           # with open(directory_pathh+"//old//NG"+str(c)+"_"+str(c)+".ngt","w") as fout: 
                                 #fout.writelines(data[1]) 
                          
                        
                            
                            file2 = open(directory_pathh2+"//new//"+arr[cc],"r")  
                            Counter2 = 0
                              
                            # Reading from file 
                            Content2 = file2.read() 
                            CoList2 = Content2.split("\n") 
                              
                            for ii in CoList2: 
                                if ii: 
                                    Counter2 += 1
                                      
                            # print("This is the number of lines in the file") 
                           # print(Counter2) 
                            bn2.append(Counter2)
                total2 = sum(bn2)
                           # print(total, "total")
                #while True:
                      #time.sleep(1)
                          
                          
                        #print(No_of_filess) 
                          
                          
                             
                jj = directory_pathh2+"/CROP_DEFECT"
                iii=len(os.listdir(jj))
                                 
                                
                yy2 = round((iii*100)/total2)  
                
                
                
                qqy_progress['value'] = yy2
                qqy_progress.step()  # increment progressbar 
                style5.configure('text5.Horizontal.TProgressbar', 
                        text='{:g} %'.format(yy2))  # update label
                 
            # Keep updating the master object to redraw the progress bar
                root.update()
                if yy2 == 100:
                    Thread(target = Bnil).start()
                    root.update()
                    break





'''
def cam2_crop():
    import os
    
    dirName2 = 'C:/Users/Administrator/Pictures'            
    listOfFile2 = os.listdir(dirName2)
    no_of_file2 = len(listOfFile2)
    for rr in range(0,no_of_file2):
                        #print (listOfFile[r])
        aaaaaa2=dirName2 +"/"+listOfFile2[rr]
       # print(aaaaaa)
    bn2 =[]                  
    import cv2
    import os
    directory_pathh2 = aaaaaa2+"//"+listOfFile2[rr]+"_A_2//"
    No_of_filess2 = len(os.listdir(directory_pathh2+'ngpointdata'))
    for cc in range(1,No_of_filess2):  
               # with open(directory_pathh+"//old//NG"+str(c)+"_"+str(c)+".ngt","w") as fout: 
                     #fout.writelines(data[1]) 
              
            
                
                file2 = open(directory_pathh2+"//new//NG"+str(cc)+"_"+str(cc)+".ngt","r") 
                Counter2 = 0
                  
                # Reading from file 
                Content2 = file2.read() 
                CoList2 = Content2.split("\n") 
                  
                for ii in CoList2: 
                    if ii: 
                        Counter2 += 1
                          
                # print("This is the number of lines in the file") 
                # print(Counter) 
                bn2.append(Counter2) 
                total2 = sum(bn2)
                print(total2, "total2")
    while True:
          #time.sleep(1)
              
              
            #print(No_of_filess) 
              
              
                 
              jj = directory_pathh2+"CROP_DEFECT"
              iii=len(os.listdir(jj))
                 
                
              yy2 = round((iii*100)/total2)
              print(yy2, "percentage")
                 
                # bb =a*2
                # my_progress['value'] < ii
              qqy_progress['value'] = yy2
              qqy_progress.step()  # increment progressbar 
              style5.configure('text5.Horizontal.TProgressbar', 
                        text='{:g} %'.format(yy2))  # update label
                 
            # Keep updating the master object to redraw the progress bar
              root.update()
              if yy2 == 100:
                    Thread(target = Bnil).start()
                    root.update()
                    break

'''

def cam3_crop():
    while True:
        
            #import os
            bn3 =[] 
            with open('C:/Users/Administrator/Desktop/test.txt') as aa: 
                 for line in aa:
                     ss=line.strip()
                    # print (ss) 
                     rr = ss.split('/')
                     
                     
            uu = ss + "/"+rr[-1] + "_B_1"
            exists = os.path.isfile(uu+"/"+"anil.txt") 
            if exists:
                directory_pathh3 = uu
                
               
                
                No_of_filess3 = len(os.listdir(directory_pathh3+'/ngpointdata'))
                arr=os.listdir(directory_pathh3+"//ngpointdata")
                for ccc in range(1,No_of_filess3):  
                           # with open(directory_pathh+"//old//NG"+str(c)+"_"+str(c)+".ngt","w") as fout: 
                                 #fout.writelines(data[1]) 
                          
                        
                            
                            file3 = open(directory_pathh3+"//new//"+arr[ccc],"r") 
                            Counter3 = 0
                              
                            # Reading from file 
                            Content3 = file3.read() 
                            CoList3 = Content3.split("\n") 
                              
                            for iii in CoList3: 
                                if iii: 
                                    Counter3 += 1
                                      
                            # print("This is the number of lines in the file") 
                            # print(Counter) 
                            bn3.append(Counter3) 
                total3 = sum(bn3)
                            
                
                      #time.sleep(1)
                          
                          
                        #print(No_of_filess) 
                          
                          
                             
                jjj = directory_pathh3+"/CROP_DEFECT"
                iii3=len(os.listdir(jjj))
                             
                            
                yy3 = round((iii3*100)/total3)
               # print(yy3, "percentage")
                             
                            # bb =a*2
                            # my_progress['value'] < ii
                wwy_progress['value'] = yy3
                wwy_progress.step()  # increment progressbar 
                style6.configure('text6.Horizontal.TProgressbar', 
                                    text='{:g} %'.format(yy3))  # update label
                             
                        # Keep updating the master object to redraw the progress bar
                root.update()
                if yy3 == 100:
                    Thread(target = Cnil).start()
                    root.update()
                    break




def cam4_crop():
    while True:
        
           # import os
            bn4 =[] 
            with open('C:/Users/Administrator/Desktop/test.txt') as aa: 
                 for line in aa:
                     ss=line.strip()
                    # print (ss) 
                     rr = ss.split('/')
       # print(aaaaaa)
            uu = ss + "/"+rr[-1] + "_B_2"
            exists = os.path.isfile(uu+"/"+"anil.txt") 
            if exists:
                directory_pathh4 = uu                  
                import cv2
               # import os
                
                No_of_filess4 = len(os.listdir(directory_pathh4+'/ngpointdata'))
                arr=os.listdir(directory_pathh4+"//ngpointdata")
                for cccc in range(1,No_of_filess4):  
                           # with open(directory_pathh+"//old//NG"+str(c)+"_"+str(c)+".ngt","w") as fout: 
                                 #fout.writelines(data[1]) 
                          
                        
                            
                            file4 = open(directory_pathh4+"//new//"+arr[cccc],"r")  
                            Counter4 = 0
                              
                            # Reading from file 
                            Content4 = file4.read() 
                            CoList4 = Content4.split("\n") 
                              
                            for iiii in CoList4: 
                                if iiii: 
                                    Counter4 += 1
                                      
                            # print("This is the number of lines in the file") 
                            # print(Counter) 
                            bn4.append(Counter4) 
                total4 = sum(bn4)
                                        
                            
                
                      #time.sleep(1)
                          
                          
                        #print(No_of_filess) 
                          
                          
                             
                jjjj = directory_pathh4+"/CROP_DEFECT"
                iii4=len(os.listdir(jjjj))
                             
                            
                yy4 = round((iii4*100)/total4)
                #print(yy4, "percentage")
                             
                            # bb =a*2
                            # my_progress['value'] < ii
                rry_progress['value'] = yy4
                rry_progress.step()  # increment progressbar 
                style7.configure('text7.Horizontal.TProgressbar', 
                                    text='{:g} %'.format(yy4))  # update label
                             
                        # Keep updating the master object to redraw the progress bar
                root.update()
                if yy4 == 100:
                    Thread(target = Dnil).start()
                    root.update()
                    break




def all_crop():
    while True:
        #try:
          #time.sleep(1)
          import glob
          with open('C:/Users/Administrator/Desktop/test.txt') as f: 
             for line in f:
                 c=line.strip()
                 #print (c) 
                 k = c.split('/')
                 #print(k)
          
             #u = c + "/"+k[-1] + "_A_1"
             #j = c + "/txt"
            # ii=len(os.listdir(j))
            
             myPath = c + "/txt"
             y = len(glob.glob1(myPath,"*.txt"))
            
             yy = round((y*100)/4)
        
             
             
        # Keep updating the master object to redraw the progress bar
             root.update()
             
             if yy == 100:
                 
                root.update()
                break 
        #except:
          # pass







             


root.mainloop()




                                            







